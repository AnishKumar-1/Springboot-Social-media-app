INSERT INTO Roles(role) VALUES ('ROLE_USER'), ('ROLE_ADMIN');

INSERT INTO Users(email, password, user_role) 
VALUES
('anish123@gmail.com', '$2a$12$W9yqdY2Ws0wUoyWldXHgrumXz47h169BUZExFaFgz.9o704MHDK2a', 1),
('rohit123@gmail.com', '$2a$12$F2xND9WeDT19b3PUeyIUwOZRUh2C5YTvh.Zgv2R5.B9BRaTTQnnkW', 2),
('aman123@gmail.com', '$2a$10$w7vaDGvuV84Mafdqb2ejDeYwCo3LQbdhWF9WgqfjUj2nHRkjHZ87q', 1),
('abhisek123@gmail.com', '$2a$10$8LfM.FKqezTRbEdElh.0LeViIGSb0w7jJxxcLkeHf/X6N7IUbKZ4K', 1);
