package social_media_post.JwtSecurity;

import java.security.Key;
import java.util.Date;
import java.util.function.Function;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtHelper {

	@Value("${SECRET_KEY}")
	private String accessKey;
	@Value("${accessExpirationTime}")
	private long accessExpirationTime;
	@Value("${refreshExpirationTime}")
	private long refreshExpirationTime;

	
	//key decoder in base64
	private Key getKey() {
		return Keys.hmacShaKeyFor(Decoders.BASE64.decode(accessKey));
	}
	
	//generate token
	public String generateToken(Authentication authentication,long expiration) {
		String username=authentication.getName();
		return Jwts.builder().header().empty().add("typ","JWT")
				.and().subject(username).issuedAt(new Date(System.currentTimeMillis()))
				.expiration(new Date(System.currentTimeMillis() + expiration))
				.signWith(getKey()).compact();
	}
	
	//generate access token
	public String generateAccessToken(Authentication authentication) {
		return generateToken(authentication,accessExpirationTime);
	}
	
	//generate refresh token
	public String generateRefreshToken(Authentication authentication) {
		return generateToken(authentication,refreshExpirationTime);
	}
	
	
	//get all claims
	public <T> T extractClaims(String token,Function<Claims, T> claimResolver) {
		Claims claim=Jwts.parser().verifyWith((SecretKey) getKey())
				.build().parseSignedClaims(token).getPayload();
		return claimResolver.apply(claim);
	}
	
	//extract username from claim
	public String extractUsername(String token) {
		return extractClaims(token,Claims::getSubject);
	}
	
	//check if token is expired or not
	public boolean isTokenExpired(String token) {
		return extractClaims(token,Claims::getExpiration).before(new Date());
	}
	
	
	//validate token
	
	public boolean validateToken(String token) {
		try {
			Jwts.parser().verifyWith((SecretKey) getKey()).build().parse(token);
			return true;
		}catch(ExpiredJwtException ex) {
			throw new ExpiredJwtException(null,null,"Token has expired");
		}catch(MalformedJwtException ex) {
			throw new MalformedJwtException("malformed jwt Token");
		}catch(Exception ex) {
			throw new RuntimeException("something went wrong");
		}catch(InternalError internal) {
			throw new InternalError("internal error");
		}
	}
	
}
