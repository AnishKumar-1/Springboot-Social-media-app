package social_media_post.Services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import social_media_post.Dto.CommentRequestDto;
import social_media_post.Dto.CommentResponse;
import social_media_post.ErrorHandling.PostorCommentNotFound;
import social_media_post.Models.UserComment;
import social_media_post.Models.UserPost;
import social_media_post.Models.Users;
import social_media_post.Repositories.CommentRepo;
import social_media_post.Repositories.PostRepo;
import social_media_post.Repositories.UserRepo;

@Service
public class CommentService {

	@Autowired
	private CommentRepo commentRepo;
	@Autowired
	private PostRepo postRepo;
	
	@Autowired
	private UserRepo userRepo;
	
	//crete comment
	public CommentResponse createComment(CommentRequestDto commentDto,Long postId) {
		if(postId==null) {
			throw new IllegalArgumentException("post id not found");
		}
		Optional<UserPost>post=postRepo.findById(postId);
		if(!post.isPresent()) {
			throw new PostorCommentNotFound("post not found with the id");
		}
		UserPost storePost=post.get();
		UserComment userComment=new UserComment();
		userComment.setComment(commentDto.getComment());
		userComment.setCreated_at(LocalDateTime.now());
		userComment.setPost(storePost);
		String email=SecurityContextHolder.getContext().getAuthentication().getName();
		Users user=userRepo.findByEmail(email);
		userComment.setUser(user);
		UserComment result=commentRepo.save(userComment);
		CommentResponse commentResponse=new CommentResponse();
		commentResponse.setComment(result.getComment());
		commentResponse.setCommentId(result.getCommentId());
		commentResponse.setCreated_at(result.getCreated_at());
		return commentResponse;
	}
	
	//get all comment
	public List<CommentResponse> getAllCommentByPostId(Long postId){
		if(postId==null || !postRepo.existsById(postId)) {
			throw new IllegalArgumentException("post id not found..");
		}
		List<CommentResponse> list=new ArrayList<>();
		List<UserComment>data=commentRepo.findByPostPostId(postId);
		for(UserComment result:data)
			list.add(new CommentResponse(result.getCommentId(),result.getComment(),result.getCreated_at(),result.getUpdated_at()));
		 return list;  
	}
	
	//get comment by id
	public CommentResponse getCommentByCommentId(Long postId,Long commentId) {
		if(postId==null || commentId==null) {
			throw new PostorCommentNotFound("postId or commentId not found");
		}
		Optional<UserPost> post=postRepo.findById(postId);
		if(!post.isPresent()) {
			throw new PostorCommentNotFound("Post not found");
		}
		Optional<UserComment> comment=commentRepo.findById(commentId);
		if(!comment.isPresent()) {
			throw new PostorCommentNotFound("comment not found");
		}
		UserComment usercomment=comment.get();
		CommentResponse result=new CommentResponse(
				usercomment.getCommentId(),usercomment.getComment(),
				usercomment.getCreated_at(),usercomment.getUpdated_at());
		return result;
		
	}
	
	//update comment by id
	public CommentResponse updateComment(CommentRequestDto commentDto,Long postId,Long commentId) {
		if(postId==null || commentId==null) {
			throw new PostorCommentNotFound("postId or commentId not found");
		}
		if(!postRepo.existsById(postId)) {
			throw new PostorCommentNotFound("Post not found");
		}
		if(!commentRepo.existsById(commentId)) {
			throw new PostorCommentNotFound("comment not found");
		}
		Optional<UserComment> comment=commentRepo.findById(commentId);
		UserComment storeComment=comment.get();
		
		storeComment.setComment(commentDto.getComment());
		storeComment.setUpdated_at(LocalDateTime.now());
		
		UserComment response=commentRepo.save(storeComment);
		CommentResponse result=new CommentResponse();
		result.setComment(response.getComment());
		result.setCommentId(response.getCommentId());
		result.setUpdated_at(response.getUpdated_at());
		return result;
	}
	
	//delete comment by id

	//update comment by id
	public String deleteComment(Long postId,Long commentId) {
		if(postId==null || commentId==null) {
			throw new PostorCommentNotFound("postId or commentId not found");
		}
		if(!postRepo.existsById(postId)) {
			throw new PostorCommentNotFound("Post not found");
		}
		if(!commentRepo.existsById(commentId)) {
			throw new PostorCommentNotFound("comment not found");
		}
		commentRepo.deleteById(commentId);
		return "comment deleted successfully..";
		
	}
}
