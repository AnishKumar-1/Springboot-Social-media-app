package social_media_post.Services;

import java.time.LocalDateTime;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import social_media_post.Dto.CommentResponse;
import social_media_post.Dto.PostRequestDto;
import social_media_post.Dto.PostResponseDto;
import social_media_post.ErrorHandling.PostorCommentNotFound;
import social_media_post.ErrorHandling.UniqueContraintViolation;
import social_media_post.Models.UserComment;
import social_media_post.Models.UserPost;
import social_media_post.Models.Users;
import social_media_post.Repositories.PostRepo;
import social_media_post.Repositories.UserRepo;
import java.util.List;
import java.util.ArrayList;

@Service
//@Slf4j
public class PostService {
	

	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private PostRepo postRepo;
	
	
	public PostResponseDto cratePost(PostRequestDto postdto) {
		try {
		UserPost userPost=new UserPost();
		userPost.setTitle(postdto.getTitle());
		userPost.setDescription(postdto.getDescription());
		String email=SecurityContextHolder.getContext().getAuthentication().getName();
		Users user=userRepo.findByEmail(email);
		userPost.setUser(user);
		userPost.setCreated_at(LocalDateTime.now());
		UserPost save=postRepo.save(userPost);
		PostResponseDto postResponseDto=new PostResponseDto();
		postResponseDto.setPostId(save.getPostId());
		postResponseDto.setTitle(save.getTitle());postResponseDto.setDescription(save.getDescription());
		postResponseDto.setCreated_at(save.getCreated_at());
	    return postResponseDto;
		}catch(DataIntegrityViolationException ex) {
			throw new UniqueContraintViolation("Post with this title already exists");
		}
	}

	
	//update post
	 public PostResponseDto updatePost(Long id, PostRequestDto postdto) {
	        Optional<UserPost> databasePost = postRepo.findById(id);
	        
	        if (!databasePost.isPresent()) {
	            throw new PostorCommentNotFound("Post not found");
	        }
	        
	        UserPost post = databasePost.get();
	        post.setTitle(postdto.getTitle());
	        post.setDescription(postdto.getDescription());
	        post.setUpdated_at(LocalDateTime.now());
	        
	        UserPost savedPost = postRepo.save(post);
	        
	        PostResponseDto result=new PostResponseDto();
	        result.setUpdated_at(LocalDateTime.now());
	        result.setPostId(savedPost.getPostId());
	        result.setTitle(savedPost.getTitle());
	        result.setDescription(savedPost.getDescription());
	        return result;
	        
	    }
	 
	   public PostResponseDto getPost(Long postId) {
	        if (postId == null) {
	            throw new IllegalArgumentException("Post ID cannot be null");
	        }
	        Optional<UserPost> post = postRepo.findById(postId);
	        if (!post.isPresent()) {
	            throw new UsernameNotFoundException("Post not found with ID: " + postId);
	        }
	        UserPost result = post.get();
	        return convertToPostResponseDto(result);
	    }
	
	 
	  // Get all posts
	    public List<PostResponseDto> getAllPosts() {
	        List<UserPost> posts = postRepo.findAll();
	        List<PostResponseDto> result = new ArrayList<>();
	        for (UserPost post : posts) {
	            result.add(convertToPostResponseDto(post));
	        }
	        return result;
	    }

	    // Convert UserPost to PostResponseDto
	    private PostResponseDto convertToPostResponseDto(UserPost post) {
	        PostResponseDto postDto = new PostResponseDto();
	        postDto.setPostId(post.getPostId());
	        postDto.setTitle(post.getTitle());
	        postDto.setDescription(post.getDescription());
	        postDto.setCreated_at(post.getCreated_at());
	        postDto.setUpdated_at(post.getUpdated_at());

	        List<CommentResponse> commentDtos = new ArrayList<>();
	        for (UserComment comment : post.getComments()) {
	        	CommentResponse commentDto = new CommentResponse();
	            commentDto.setCommentId(comment.getCommentId());
	            commentDto.setComment(comment.getComment());
	            commentDto.setCreated_at(comment.getCreated_at());
	            commentDto.setUpdated_at(comment.getUpdated_at());
	            commentDtos.add(commentDto);
	        }
	        postDto.setComments(commentDtos);

	        return postDto;
	    }
	 
	 //delete post
	    public String deletePost(Long id) {
	        if (id == null) {
	            throw new IllegalArgumentException("Post ID cannot be null");
	        }

//	        log.info("Deleting post with ID: {}", id);
	        Optional<UserPost> userpost=postRepo.findById(id);
	        if(!userpost.isPresent()) {
	            throw new PostorCommentNotFound("Post with ID " + id + " does not exist");
	        }
	        postRepo.deleteById(id);

	        return "Post deleted successfully";
	    }
	 
}
