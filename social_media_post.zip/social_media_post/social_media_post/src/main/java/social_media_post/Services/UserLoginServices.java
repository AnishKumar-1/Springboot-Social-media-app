package social_media_post.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import social_media_post.AppSecurity.CustomUserDetails;
import social_media_post.Dto.JwtResponse;
import social_media_post.JwtSecurity.JwtHelper;
import social_media_post.Models.Users;

@Service
public class UserLoginServices {

   @Autowired
   private JwtHelper jwtHelper;

    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private CustomUserDetails customUserDetails;


    public JwtResponse userLogin(Users user) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword())
            );
            SecurityContextHolder.getContext().setAuthentication(authentication);
            String accessToken=jwtHelper.generateAccessToken(authentication);
            String refreshToken=jwtHelper.generateRefreshToken(authentication);           
            JwtResponse jwtResponse=new JwtResponse(accessToken,refreshToken);
             return jwtResponse;
        } catch (Exception ex) {
            throw new UsernameNotFoundException("Bad credentials", ex);
        }
    }


	public String refreshTokenMethod(String oldToken) {
		// TODO Auto-generated method stub
		if(jwtHelper.validateToken(oldToken) && !jwtHelper.isTokenExpired(oldToken)) {
			String username=jwtHelper.extractUsername(oldToken);
			UserDetails userdetails=customUserDetails.loadUserByUsername(username);
			Authentication authentication=new UsernamePasswordAuthenticationToken(userdetails,null,userdetails.getAuthorities());
			SecurityContextHolder.getContext().setAuthentication(authentication);
			return jwtHelper.generateRefreshToken(authentication);
		}else {
            throw new IllegalArgumentException("Invalid or expired refresh token");
		}
	}
    
   
}