package social_media_post.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import social_media_post.Dto.CommentResponse;
import social_media_post.Dto.PostResponseDto;
import social_media_post.Dto.RoleDto;
import social_media_post.Dto.UserResponseDto;
import social_media_post.Models.UserComment;
import social_media_post.Models.UserPost;
import social_media_post.Models.Users;
import social_media_post.Repositories.UserRepo;
import java.util.*;

@Service
public class UserService {

    @Autowired
    private UserRepo userRepo;

    public List<UserResponseDto> getAllUsers() {
        List<Users> userList = userRepo.findAll();
        List<UserResponseDto> result = new ArrayList<>();

        for (Users user : userList) {
            UserResponseDto dto = new UserResponseDto();
            dto.setUserId(user.getUserId());
            dto.setEmail(user.getEmail());

            RoleDto roleDto = new RoleDto();
            roleDto.setRoleId(user.getRole().getRoleId());
            roleDto.setRole(user.getRole().getRole());
            dto.setRole(roleDto);

            List<PostResponseDto> postDtos = new ArrayList<>();
            for (UserPost post : user.getPost()) {
                PostResponseDto postDto = new PostResponseDto();
                postDto.setPostId(post.getPostId());
                postDto.setTitle(post.getTitle());
                postDto.setDescription(post.getDescription());
                postDto.setCreated_at(post.getCreated_at());
                postDto.setUpdated_at(post.getUpdated_at());

                List<CommentResponse> commentDtos = new ArrayList<>();
                for (UserComment comment : post.getComments()) {
                	CommentResponse commentDto = new CommentResponse();
                    commentDto.setCommentId(comment.getCommentId());
                    commentDto.setComment(comment.getComment());
                    commentDto.setCreated_at(comment.getCreated_at());
                    commentDto.setUpdated_at(comment.getUpdated_at());
                    commentDtos.add(commentDto);
                }
                postDto.setComments(commentDtos);

                postDtos.add(postDto);
            }
            dto.setPost(postDtos);

            result.add(dto);
        }
        return result;
    }
}