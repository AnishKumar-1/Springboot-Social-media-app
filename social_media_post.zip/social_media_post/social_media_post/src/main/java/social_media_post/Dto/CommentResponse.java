package social_media_post.Dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CommentResponse {
	
	private Long commentId;
	private String comment;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private LocalDateTime created_at;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private LocalDateTime updated_at;
}
