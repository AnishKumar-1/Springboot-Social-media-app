package social_media_post.Dto;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PostResponseDto {
	private Long postId;
	private String title;
	private String description;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private LocalDateTime created_at;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private LocalDateTime updated_at;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<CommentResponse> comments;
}
