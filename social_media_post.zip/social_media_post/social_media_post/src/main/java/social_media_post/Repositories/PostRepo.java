package social_media_post.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import social_media_post.Models.UserPost;

public interface PostRepo extends JpaRepository<UserPost, Long>{

}
