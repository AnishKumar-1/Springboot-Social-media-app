package social_media_post.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import social_media_post.Models.Users;

public interface UserRepo extends JpaRepository<Users, Long>{

	public Users findByEmail(String email);
}
