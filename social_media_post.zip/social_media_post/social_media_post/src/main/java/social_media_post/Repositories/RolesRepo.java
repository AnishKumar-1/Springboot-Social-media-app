package social_media_post.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import social_media_post.Models.Roles;

public interface RolesRepo extends JpaRepository<Roles, Long>{

}
