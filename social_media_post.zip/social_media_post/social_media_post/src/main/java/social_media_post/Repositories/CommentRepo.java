package social_media_post.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import social_media_post.Models.UserComment;
import java.util.List;

@Repository
public interface CommentRepo extends JpaRepository<UserComment, Long>{
    List<UserComment> findByPostPostId(Long postId);

}
