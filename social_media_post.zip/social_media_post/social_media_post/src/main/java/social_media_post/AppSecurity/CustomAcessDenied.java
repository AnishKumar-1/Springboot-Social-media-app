package social_media_post.AppSecurity;

import java.io.IOException;


import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class CustomAcessDenied implements AccessDeniedHandler{
//	@Autowired
//	@Qualifier("handlerExceptionResolver")
//	 private HandlerExceptionResolver exceptionResolver;

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response,
			AccessDeniedException accessDeniedException) throws IOException, ServletException {
		// TODO Auto-generated method stub
//		exceptionResolver.resolveException(request, response, null, accessDeniedException);
		
	}
}
