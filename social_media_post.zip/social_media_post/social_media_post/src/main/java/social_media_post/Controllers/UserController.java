package social_media_post.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import social_media_post.Dto.JwtResponse;
import social_media_post.Dto.UserResponseDto;
import social_media_post.Models.Users;
import social_media_post.Services.UserLoginServices;
import social_media_post.Services.UserService;

@RestController
@RequestMapping("${app.base.url}")
public class UserController {
	
	@Autowired
	private UserLoginServices userLoginServices;
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/login")
	public ResponseEntity<JwtResponse> login(@RequestBody Users user) {		
		return new ResponseEntity<>(userLoginServices.userLogin(user),HttpStatus.OK);
	}
	
	@GetMapping("/users")
	public ResponseEntity<List<UserResponseDto>> getAllUsers(){
	  return ResponseEntity.ok(userService.getAllUsers());
	}
	
	 
	@GetMapping("/admin")
//	@PreAuthorize("hasRole('ADMIN')")
	public String test() {
		return "hello admin";
	}
	
	//get refresh token
	@PostMapping("/refresh")
	public ResponseEntity<String> refreshAccessToken(HttpServletRequest request) {
        String token = request.getHeader("Authorization");
        
        if (token == null || !token.startsWith("Bearer ")) {
            return new ResponseEntity<>("Token not found or invalid", HttpStatus.BAD_REQUEST);
        }
        
        try {
            String oldToken = token.substring(7);
            String newToken = userLoginServices.refreshTokenMethod(oldToken);
            return new ResponseEntity<>(newToken, HttpStatus.OK);
        } catch (IllegalArgumentException ex) {
            return new ResponseEntity<>("Invalid token", HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
