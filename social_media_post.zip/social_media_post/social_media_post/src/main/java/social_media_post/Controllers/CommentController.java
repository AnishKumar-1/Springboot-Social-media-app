package social_media_post.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import social_media_post.Dto.CommentRequestDto;
import social_media_post.Dto.CommentResponse;
import social_media_post.Services.CommentService;

@RestController
@RequestMapping("${app.base.url}")
public class CommentController {

	@Autowired
	private CommentService commentService;
	
	//create comment
	@PostMapping("/comment/{postId}")
	public ResponseEntity<CommentResponse> createComment(@Valid @RequestBody CommentRequestDto commentDto,@PathVariable Long postId){
		return new ResponseEntity<>(commentService.createComment(commentDto, postId),HttpStatus.CREATED);
	}
	//getall comment
		@GetMapping("/comment/{postId}")
		public ResponseEntity<List<CommentResponse>> getAllComment(@PathVariable Long postId){
			return new ResponseEntity<>(commentService.getAllCommentByPostId(postId),HttpStatus.OK);
		}
	//get comment by id
		@GetMapping("/comment/{postId}/{id}")
		public ResponseEntity<CommentResponse> getCommentById(@PathVariable Long postId,@PathVariable Long id){
			return new ResponseEntity<>(commentService.getCommentByCommentId(postId,id),HttpStatus.OK);
		}
	//update comment by id
		@PutMapping("/comment/{postId}/{id}")
		public ResponseEntity<CommentResponse> updateComment(@Valid @RequestBody CommentRequestDto commentDto,@PathVariable Long postId,@PathVariable Long id){
			return ResponseEntity.ok(commentService.updateComment(commentDto,postId,id));
		}
	//delete comment by id
		
		@DeleteMapping("/comment/{postId}/{id}")
		public ResponseEntity<String> deleteComment(@PathVariable Long postId,@PathVariable Long id){
			return ResponseEntity.ok(commentService.deleteComment(postId,id));
		}
	
}
