package social_media_post.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import social_media_post.Dto.PostRequestDto;
import social_media_post.Dto.PostResponseDto;
import social_media_post.Services.PostService;

@RestController
@RequestMapping("${app.base.url}")
public class PostController {

	@Autowired
	private PostService postService;
	
	//to create post
	@PostMapping("/post")
	public ResponseEntity<PostResponseDto> createPost(@Valid @RequestBody PostRequestDto postdto){
		return new ResponseEntity<>(postService.cratePost(postdto),HttpStatus.CREATED);
	}
	
	
	//update post by id
	@PutMapping("/post/{id}")
	public ResponseEntity<PostResponseDto> updatePost(@PathVariable Long id,@Valid @RequestBody PostRequestDto postdto) {
		PostResponseDto updatedPost = postService.updatePost(id, postdto);
        return ResponseEntity.ok(updatedPost);
	}
	
	
	//get post by id
	@GetMapping("/post/{id}")
	public ResponseEntity<PostResponseDto> getPost(@PathVariable Long id) {
        return ResponseEntity.ok(postService.getPost(id));
	}
	
	
	//get post by id
	@GetMapping("/post")
	public ResponseEntity<List<PostResponseDto>> getAllPost() {
        return ResponseEntity.ok(postService.getAllPosts());
	}
	
	
	//delete post by id
		@DeleteMapping("/post/{id}")
		public ResponseEntity<String> deletePost(@PathVariable Long id) {
	        return ResponseEntity.ok(postService.deletePost(id));
		}
}
