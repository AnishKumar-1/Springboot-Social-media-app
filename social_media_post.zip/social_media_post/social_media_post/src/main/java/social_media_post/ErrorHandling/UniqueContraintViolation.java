package social_media_post.ErrorHandling;

public class UniqueContraintViolation extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public UniqueContraintViolation(String msg) {
		super(msg);
	}

}
