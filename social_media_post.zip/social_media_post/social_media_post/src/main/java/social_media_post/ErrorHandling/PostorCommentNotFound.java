package social_media_post.ErrorHandling;

public class PostorCommentNotFound extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public PostorCommentNotFound(String msg) {
		super(msg);
	}
}
