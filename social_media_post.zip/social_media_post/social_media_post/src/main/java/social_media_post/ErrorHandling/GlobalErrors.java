package social_media_post.ErrorHandling;


import java.nio.file.AccessDeniedException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.management.RuntimeErrorException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import jakarta.servlet.http.HttpServletRequest;

@RestControllerAdvice
public class GlobalErrors {

    private final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @ExceptionHandler(Throwable.class)
    public ResponseEntity<CustomErrorResponse> handleExceptions(Throwable ex, HttpServletRequest request) {
        CustomErrorResponse customError = new CustomErrorResponse();
        customError.setPath(request.getRequestURI());
        customError.setMessage(ex.getMessage());
        customError.setTimestamp(simpleDateFormat.format(new Date()));

        if (ex instanceof UsernameNotFoundException) {
            customError.setStatus(HttpStatus.NOT_FOUND);
            customError.setStatusCode(HttpStatus.NOT_FOUND.value());
            return new ResponseEntity<>(customError, HttpStatus.NOT_FOUND);
        } else if (ex instanceof AccessDeniedException) {
            customError.setStatus(HttpStatus.FORBIDDEN);
            customError.setStatusCode(HttpStatus.FORBIDDEN.value());
            return new ResponseEntity<>(customError, HttpStatus.FORBIDDEN);
        } else if (ex instanceof IllegalArgumentException) {
            customError.setStatus(HttpStatus.BAD_REQUEST);
            customError.setStatusCode(HttpStatus.BAD_REQUEST.value());
            return new ResponseEntity<>(customError, HttpStatus.BAD_REQUEST);
        } else if (ex instanceof ExpiredJwtException || ex instanceof MalformedJwtException || ex instanceof UnsupportedJwtException) {
            customError.setStatus(HttpStatus.BAD_REQUEST);
            customError.setStatusCode(HttpStatus.BAD_REQUEST.value());
            return new ResponseEntity<>(customError, HttpStatus.BAD_REQUEST);
        } else if (ex instanceof RuntimeErrorException) {
        	System.out.print("runtime class called..");
            customError.setStatus(HttpStatus.FORBIDDEN);
            customError.setStatusCode(HttpStatus.FORBIDDEN.value());
            return new ResponseEntity<>(customError, HttpStatus.FORBIDDEN);
        } else if (ex instanceof InternalError) {
            customError.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
            customError.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(customError, HttpStatus.INTERNAL_SERVER_ERROR);
        } else if (ex instanceof Exception) {
            customError.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
            customError.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(customError, HttpStatus.INTERNAL_SERVER_ERROR);
        } else if (ex instanceof Error) {
            customError.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
            customError.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(customError, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        else if (ex instanceof PostorCommentNotFound) {
            customError.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
            customError.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(customError, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        else {
            customError.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
            customError.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(customError, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }
}