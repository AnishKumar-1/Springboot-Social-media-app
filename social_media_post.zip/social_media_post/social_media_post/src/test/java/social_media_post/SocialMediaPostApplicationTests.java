package social_media_post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialMediaPostApplicationTests {

	@Test
	void contextLoads() {
	}

}
